# kodexplorer-plugins-doc2pdf
kodexplorer doc2pdf plugin
