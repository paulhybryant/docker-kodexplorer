<?php
return array(
  "doc2pdf.meta.name"				=> "转换doc文件为pdf",
  "doc2pdf.meta.title"				=> "转换doc文件为pdf",
  "doc2pdf.meta.desc"				=> "转换doc文件为pdf",
);
