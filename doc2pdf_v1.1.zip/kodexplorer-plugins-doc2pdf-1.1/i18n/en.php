<?php
return array(
  "doc2pdf.meta.name"				=> "Convert doc to pdf",
  "doc2pdf.meta.title"				=> "Convert doc to pdf",
  "doc2pdf.meta.desc"				=> "Convert doc to pdf",
);
